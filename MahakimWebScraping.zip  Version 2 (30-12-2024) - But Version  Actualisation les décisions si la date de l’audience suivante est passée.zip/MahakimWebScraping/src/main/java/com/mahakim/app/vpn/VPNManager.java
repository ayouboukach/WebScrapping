package com.mahakim.app.vpn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;

public class VPNManager {

    private static final String VPN_PATH = "C:\\Program Files (x86)\\Avira\\VPN\\Avira.WebAppHost.exe";
    private static final String API_URL = "https://www.mahakim.ma/middleware/api/SuiviDossiers/ListeDicisions?idDossier=12456019&typeaffaire=DC";
    private static final int MAX_CALLS = 5;
    private static final int TOTAL_VPN_INSTANCES = 10;
    private static final int[] RATE_LIMIT_CODES = {429, 403};
    private static final int BACKOFF_MAX_WAIT = 300;
    private static final String USER_AGENT = "MyScript/1.0";

    private static int requestCount = 0;
    private static int currentInstance = 0;

    private static final Logger logger = Logger.getLogger(VPNManager.class.getName());

    public static void main(String[] args) {
        try {
            logger.info("Initializing VPN manager...");
            startVPN();

            int backoffTime = 5;
            while (true) {
                if (requestCount >= MAX_CALLS) {
                    logger.info("Proactive VPN switch before hitting rate limit...");
                    switchVPNInstance();
                }

                HttpURLConnection response = makeRequest(API_URL);
                if (response == null) {
                    logger.info("Handling rate limit. Switching VPN...");
                    switchVPNInstance();
                    Thread.sleep(backoffTime * 1000);
                    backoffTime = Math.min(backoffTime * 2, BACKOFF_MAX_WAIT);
                    continue;
                }

                backoffTime = 5;
                Thread.sleep((long)(Math.random() * 100) + 100);
            }
        } catch (InterruptedException e) {
            logger.info("Interrupted. Exiting...");
        } finally {
            logger.info("Cleaning up and stopping VPN...");
            stopVPN();
        }
    }

    private static void startVPN() {
        try {
            logger.info("Starting VPN connection...");
            Process process = new ProcessBuilder(VPN_PATH, "start").start();
            process.waitFor();
            Thread.sleep(5000);
        } catch (IOException | InterruptedException e) {
            logger.severe("Error starting VPN: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void stopVPN() {
        try {
            logger.info("Stopping VPN connection...");
            Process process = new ProcessBuilder(VPN_PATH, "stop").start();
            process.waitFor();
            Thread.sleep(2000);
        } catch (IOException | InterruptedException e) {
            logger.severe("Error stopping VPN: " + e.getMessage());
        }
    }

    private static void switchVPNInstance() {
        try {
            stopVPN();
            currentInstance = (currentInstance + 1) % TOTAL_VPN_INSTANCES;
            logger.info("Switched to VPN instance " + currentInstance + ".");
            startVPN();

            String previousIP = null;
            while (true) {
                String newIP = verifyNewIP(previousIP);
                if (newIP != null) {
                    break;
                }
                Thread.sleep(5000);
            }

            requestCount = 0;
        } catch (InterruptedException e) {
            logger.severe("Error switching VPN instance: " + e.getMessage());
        }
    }

    private static String verifyNewIP(String previousIP) {
        try {
            String currentIP = getPublicIP();
            logger.info("Current public IP: " + currentIP);
            if (currentIP.equals(previousIP)) {
                logger.warning("VPN failed to assign a new IP. Retrying...");
                return null;
            }
            return currentIP;
        } catch (IOException e) {
            logger.warning("Unable to fetch public IP. Proceeding with caution.");
            return null;
        }
    }

    private static String getPublicIP() throws IOException {
        URL url = new URL("https://api.ipify.org");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        return response.toString();
    }

    private static HttpURLConnection makeRequest(String url) {
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setConnectTimeout(10000);

            int statusCode = connection.getResponseCode();
            requestCount++;
            logger.info("Request " + requestCount + ": Status " + statusCode);

            for (int code : RATE_LIMIT_CODES) {
                if (statusCode == code) {
                    logger.warning("Rate limit exceeded (Status " + statusCode + ").");
                    return null;
                }
            }

            return connection;
        } catch (IOException e) {
            logger.severe("Request error: " + e.getMessage());
            return null;
        }
    }
}
