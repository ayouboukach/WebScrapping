package com.mahakim.app.services.dossiers;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.mahakim.app.client.APIClientService;
import com.mahakim.app.entities.DossierEntity;
import com.mahakim.app.mapper.DossierMapper;
import com.mahakim.app.repos.DossierRepo;
import com.mahakim.app.request.model.DossierRequestBody;
import com.mahakim.app.services.dossiers.decisions.DecisionService;
import com.mahakim.app.services.dossiers.parties.PartieService;
import com.mahakim.app.services.juridictions.JuridictionService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class DossierServiceImpl implements DossierService {

    private final DossierRepo dossierRepo;
    private final DossierMapper dossierMapper;
    private final DecisionService decisionService;
    private final JuridictionService juridictionService;
    private final APIClientService apiClientService;
    private final PartieService partieService;

    @Override
    public List<DossierEntity> refreshDossiers(String year, String codeDossier, String startWithNumeroDossier,
                                               int range, int idJuidiction) throws ParseException, StreamReadException, DatabindException, IOException {
        List<DossierEntity> dossiersFetched = fetchDossiersFromAPI(year, codeDossier, startWithNumeroDossier, idJuidiction, range);

        try {
			 if (!dossiersFetched.isEmpty()) {
            updateDossiersWithAdditionalInfo(dossiersFetched);
            dossierRepo.saveAll(dossiersFetched);
            partieService.refreshPartiesByDossiersFromAPIAndSave(dossiersFetched);
            log.info("Dossiers refreshed successfully");
        }
		} catch (Exception e) {
			e.printStackTrace();
		}
       

        return dossiersFetched;
    }

    @Override
    public DossierRequestBody getDossierById() {
        // Implementation to be done
        return null;
    }

    // Private Methods
    private List<DossierEntity> fetchDossiersFromAPI(String year, String codeDossier, String startWithNumeroDossier, int idJuidiction, int range) throws ParseException {
        return dossierMapper.listBodyToEntity(
            IntStream.range(0, range)
                .mapToObj(i -> apiClientService.getDossierByNumeroComplet(
                        generateDossierNumber(year, codeDossier, startWithNumeroDossier, i),
                        Integer.toString(idJuidiction)))
                .filter(Objects::nonNull) // Filter out null DossierRequestBody
                .collect(Collectors.toList())
        );
    }


    private void updateDossiersWithAdditionalInfo(List<DossierEntity> dossiers) throws ParseException {
        dossiers = juridictionService.refreshJuridictionsByDossiersFromDb(dossiers);
        dossiers = decisionService.refreshDecisionsByDossiersFromAPI(dossiers);
        log.debug("Dossiers updated with juridictions and decisions");
    }

    private String generateDossierNumber(String year, String codeDossier, String startWithNumeroDossier, int i) {
        return year.concat(codeDossier).concat(Integer.toString(Integer.parseInt(startWithNumeroDossier) + i));
    }
}
