package com.mahakim.app.services.avocats;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mahakim.app.client.APIClientService;
import com.mahakim.app.entities.AvocatEntity;
import com.mahakim.app.entities.PartieEntity;
import com.mahakim.app.mapper.AvocatMapper;

import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class AvocatServiceImpl implements AvocatService {

    private final APIClientService apiClientService;
    private final AvocatMapper avocatMapper;

    @Override
    public List<PartieEntity> refreshAvocatsByPartiesFromAPI(List<PartieEntity> parties) {
        return parties.stream()
                .peek(this::fetchAndSetAvocats)
                .collect(Collectors.toList());
    }

    private void fetchAndSetAvocats(PartieEntity partie) {
        Set<AvocatEntity> avocats = Optional.ofNullable(apiClientService
                .getAvocatsByIdPartie(String.valueOf(partie.getIdPartie()), partie.getCodeTypePersonne(), "DC"))
                .orElseGet(List::of)
                .stream()
                .map(avocatMapper::bodyToEntity)
                .collect(Collectors.toSet());

        // Only set avocats if the set is not empty
        if (!avocats.isEmpty()) {
            avocats.forEach(avocat -> avocat.setParties(Set.of(partie)));
            partie.setAvocats(avocats);
        }
    }
}