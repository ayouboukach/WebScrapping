package com.mahakim.app.vpn;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class AviraVpnController {

    // Connect to the VPN using the system's rasdial command
    public static void connectToVpn() {
        try {
            // Adjust this command based on your VPN's name and credentials
            String command = "rasdial \"Avira VPN\" username password"; // Replace with actual credentials
            Process process = Runtime.getRuntime().exec(command);
            printProcessOutput(process);  // Optionally print the output for debugging
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Disconnect from the VPN
    public static void disconnectVpn() {
        try {
            String command = "rasdial \"Avira VPN\" /disconnect";  // Disconnect VPN
            Process process = Runtime.getRuntime().exec(command);
            printProcessOutput(process);  // Optionally print the output for debugging
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Helper method to print the output of a system command (useful for debugging)
    private static void printProcessOutput(Process process) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
