package com.mahakim.app.services.dossiers.decisions;

import java.text.ParseException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mahakim.app.client.APIClientService;
import com.mahakim.app.entities.DecisionEntity;
import com.mahakim.app.entities.DossierEntity;
import com.mahakim.app.mapper.DecisionMapper;
import com.mahakim.app.repos.DecisionRepo;
import com.mahakim.app.repos.DossierRepo;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class DecisionServiceImpl implements DecisionService {

    private final DecisionRepo decisionRepo;
    private final DossierRepo dossierRepo;
    private final DecisionMapper decisionMapper;
    private final APIClientService apiClientService;

    // Public API Methods
    @Override
    public List<DossierEntity> refreshDecisionsByDossiersFromAPI(List<DossierEntity> dossiers) throws ParseException {
        var groupedDecisions = groupDecisionsByDossierFromDossiers(dossiers);
        groupedDecisions = processGroupedDecisions(groupedDecisions);
        return updateDossiersWithDecisions(groupedDecisions);
    }

    @Override
    public List<DecisionEntity> saveDecisionsByIdDossierFromAPI(int id) throws ParseException {
        return decisionRepo.saveAll(fetchDecisionsFromAPI(id));
    }

    @Override
    public void createDecisions() {
        // TODO Auto-generated method stub
    }

    @Override
    public DecisionEntity getDecisionById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<DecisionEntity> getDecisionsByDossier() {
        // TODO Auto-generated method stub
        return null;
    }

    // Private Helper Methods
    private Map<DossierEntity, List<DecisionEntity>> groupDecisionsByDossierFromDossiers(List<DossierEntity> dossiers) {
        var decisions = fetchDecisionsForDossiers(dossiers);
        return mapDecisionsToDossiers(decisions, dossiers);
    }

    private List<DecisionEntity> fetchDecisionsForDossiers(List<DossierEntity> dossiers) {
        return Optional.ofNullable(decisionRepo.findAllByDossierIn(dossiers)).orElse(Collections.emptyList());
    }

    private Map<DossierEntity, List<DecisionEntity>> mapDecisionsToDossiers(List<DecisionEntity> decisions, List<DossierEntity> dossiers) {
        var dossierDecisionMap = new HashMap<DossierEntity, List<DecisionEntity>>();
        dossiers.forEach(dossier -> dossierDecisionMap.putIfAbsent(dossier, new ArrayList<>()));
        decisions.forEach(decision -> Optional.ofNullable(decision.getDossier())
                .ifPresent(dossier -> dossierDecisionMap.computeIfAbsent(dossier, k -> new ArrayList<>()).add(decision)));
        return dossierDecisionMap;
    }

    private Map<DossierEntity, List<DecisionEntity>> processGroupedDecisions(Map<DossierEntity, List<DecisionEntity>> groupedDecisions) {
        return groupedDecisions.entrySet().stream()
                .map(this::processDossier)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    private Map.Entry<DossierEntity, List<DecisionEntity>> processDossier(Map.Entry<DossierEntity, List<DecisionEntity>> entry) {
        var dossier = entry.getKey();
        var decisions = entry.getValue();
        try {
            var refreshedDecisions = refreshDecisionsByDossier(decisions, dossier);
            updateDossierWithDecisions(dossier, refreshedDecisions);
            return new AbstractMap.SimpleEntry<>(dossier, refreshedDecisions);
        } catch (ParseException e) {
            log.error("Error refreshing decisions for dossier: " + dossier.getIdDossierCivil(), e);
            return new AbstractMap.SimpleEntry<>(dossier, Collections.emptyList());
        }
    }

    private List<DecisionEntity> refreshDecisionsByDossier(List<DecisionEntity> decisionsFromDb, DossierEntity dossier) throws ParseException {
        var decisionsFromAPI = fetchDecisionsFromAPI(dossier);
        if (!decisionsFromDb.isEmpty()) {
            updateDecisionKeys(decisionsFromAPI, decisionsFromDb);
        }
        return decisionsFromAPI;
    }

    private List<DecisionEntity> fetchDecisionsFromAPI(DossierEntity dossier) throws ParseException {
        return decisionMapper.listBodyToEntity(apiClientService.getDecisionsByIdDossier(String.valueOf(dossier.getIdDossierCivil()), "DC"));
    }

    private void updateDecisionKeys(List<DecisionEntity> decisionsFromAPI, List<DecisionEntity> decisionsFromDb) {
        decisionsFromAPI.forEach(apiDecision -> 
            decisionsFromDb.stream()
                .filter(apiDecision::equals)
                .findFirst()
                .ifPresent(dbDecision -> apiDecision.setIdDecisionKey(dbDecision.getIdDecisionKey()))
        );
    }

    private void updateDossierWithDecisions(DossierEntity dossier, List<DecisionEntity> refreshedDecisions) {
        dossier.setDecisions(refreshedDecisions);
        refreshedDecisions.forEach(decision -> decision.setDossier(dossier));
    }

    private List<DossierEntity> updateDossiersWithDecisions(Map<DossierEntity, List<DecisionEntity>> groupedDecisions) {
        return groupedDecisions.entrySet().stream()
                .map(entry -> {
                    var dossier = entry.getKey();
                    var decisions = entry.getValue();
                    updateDossierWithDecisions(dossier, decisions);
                    return dossier;
                })
                .collect(Collectors.toList());
    }

    private List<DecisionEntity> fetchDecisionsFromAPI(int dossierId) throws ParseException {
        return decisionMapper.listBodyToEntity(apiClientService.getDecisionsByIdDossier(String.valueOf(dossierId), "DC"));
    }
    
    
    private Map<DossierEntity, List<DecisionEntity>> groupDecisionsByDossierFromDecisions(List<DecisionEntity> decisionList) {
        return decisionList.stream()
                .collect(Collectors.groupingBy(DecisionEntity::getDossier));
    }

    @Scheduled(fixedRate = 3600000) //chaque heure
//    @Override
    public void fetchAndSaveNewDecisionsEvery5Seconds() {
        List<DecisionEntity> decisionsFromDb =decisionRepo.findDecisionsWithPastDateAndExcludedType();
        log.info("Fetched decisions: {}", decisionsFromDb);

        Map<DossierEntity, List<DecisionEntity>> groupedDecisions = groupDecisionsByDossierFromDecisions(decisionsFromDb);
        Map<DossierEntity, List<DecisionEntity>> processedGroupedDecisions = processGroupedDecisions(groupedDecisions);
        List<DossierEntity> dossierList = processedGroupedDecisions.keySet().stream()
        	    .collect(Collectors.toList());
		dossierRepo.saveAll(updateDossiersWithDecisions(processedGroupedDecisions));
		decisionRepo.removeDuplicateDecisionsByDossiers(dossierList);
        log.info("All decisions with today's audience refreshed: {}", processedGroupedDecisions);
    }
}
