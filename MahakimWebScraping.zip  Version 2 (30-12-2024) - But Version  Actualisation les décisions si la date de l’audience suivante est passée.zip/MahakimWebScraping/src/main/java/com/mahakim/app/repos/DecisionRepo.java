package com.mahakim.app.repos;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mahakim.app.entities.DecisionEntity;
import com.mahakim.app.entities.DossierEntity;

public interface DecisionRepo extends JpaRepository<DecisionEntity , Integer> {

	List<DecisionEntity> findByDossier(DossierEntity dossier);
	
	List<DecisionEntity> findAllByDossierIn(List<DossierEntity> dossiers);
	
	@Query("SELECT d FROM DecisionEntity d WHERE " +
	           "FUNCTION('DATE', d.dateTimeNextAudience) = FUNCTION('DATE', CURRENT_DATE) " +
	           "AND d.typeDecision != 'حكم قطعي'")
	    List<DecisionEntity> findDecisionsForToday();
	
	@Query("SELECT d FROM DecisionEntity d WHERE d.dateTimeNextAudience < CURRENT_TIMESTAMP AND d.typeDecision != 'حكم قطعي'")
    List<DecisionEntity> findDecisionsWithPastDateAndExcludedType();
	
    Optional<DecisionEntity> findTopByDossierOrderByDateTimeNextAudienceDesc(DossierEntity dossier);
    
    @Query("SELECT d FROM DecisionEntity d WHERE d.dossier IN :dossiers")
    List<DecisionEntity> findByDossiers(List<DossierEntity> dossiers);
    
    void deleteByIdDecisionIn(Set<Integer> ids);
    
    @Modifying
    @Query("DELETE FROM DecisionEntity d WHERE d.idDecisionKey IN (" +
           "SELECT MAX(d2.idDecisionKey) FROM DecisionEntity d2 " +
           "WHERE d2.dateTimeDecision = d.dateTimeDecision " +
           "AND d2.idDecision = d.idDecision " +
           "AND d2.dossier IN :dossiers " +  // Use IN to filter by a list of DossierEntity
           "GROUP BY d2.dateTimeDecision, d2.idDecision " +
           "HAVING COUNT(d2) > 1)")
    void removeDuplicateDecisionsByDossiers(@Param("dossiers") List<DossierEntity> dossiers);


}
